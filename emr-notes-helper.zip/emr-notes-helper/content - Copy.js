// content.js (parent-frame controller for CKEditor about:blank iframe)

(() => {
  // ---- Debug markers ----
  document.documentElement.dataset.emrHelperInjected = "1";
  console.log("[EMR Helper] content.js version = 2026-02-27-D");

  try {
    chrome.runtime.sendMessage({
      type: "PING",
      href: location.href,
      top: window.top === window.self,
    });
  } catch (e) {}

  // ---- Utilities ----
  const normalize = (s) =>
    (s || "")
      .toString()
      .replace(/\u00A0/g, " ")
      .trim();

  const debounce = (fn, ms) => {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), ms);
    };
  };

  function escapeRegex(s) {
    return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  // ---- Diagnosis config loading ----
  let diagnosesConfig = [];

  async function loadDiagnosesConfig() {
    try {
      const url = chrome.runtime.getURL("diagnoses.json");
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`Failed to load diagnoses.json: ${response.status}`);
      }

      diagnosesConfig = await response.json();
      console.log("[EMR] diagnoses loaded:", diagnosesConfig);
    } catch (err) {
      console.error("[EMR] could not load diagnoses.json", err);
      diagnosesConfig = [];
    }
  }

  function findDiagnosisMatch(text) {
    const normalized = (text || "").toUpperCase();

    for (const dx of diagnosesConfig) {
      for (const keyword of dx.keywords || []) {
        const pattern = new RegExp(
          `(^|[^A-Z0-9])${escapeRegex(keyword.toUpperCase())}([^A-Z0-9]|$)`,
          "i",
        );

        if (pattern.test(normalized)) {
          return dx;
        }
      }
    }

    return null;
  }

  // ---- CKEditor iframe access ----
  function getCkEditorTarget() {
    const frame = document.querySelector("iframe.cke_wysiwyg_frame");
    if (!frame) return null;

    try {
      const doc = frame.contentDocument || frame.contentWindow?.document;
      const body = doc?.body || null;
      if (!doc || !body) return null;
      return { frame, doc, body };
    } catch {
      return null;
    }
  }

  function getEditorText() {
    const t = getCkEditorTarget();
    if (!t) return "";
    return normalize(t.body.innerText);
  }

  // ---- Popup state ----
  let popup = null;
  let lastMatched = null;
  const dismissedUntilByDiagnosis = {}; //dismisses per-diagnosis map

  function ensurePopup() {
    if (popup && document.contains(popup)) return popup;

    popup = document.createElement("div");
    popup.id = "emr-helper-popup";

    popup.style.position = "fixed";
    popup.style.display = "none";
    popup.style.width = "520px";
    popup.style.maxWidth = "95vw";
    popup.style.background = "#fff";
    popup.style.border = "1px solid #d0d7de";
    popup.style.borderRadius = "12px";
    popup.style.boxShadow = "0 10px 28px rgba(0,0,0,0.18)";
    popup.style.padding = "12px 12px 10px 12px";
    popup.style.zIndex = "2147483647";
    popup.style.fontFamily = "Arial, sans-serif";
    popup.style.fontSize = "13px";
    popup.style.color = "#111";
    popup.style.pointerEvents = "auto";
    popup.style.maxHeight = "85vh";
    popup.style.overflow = "hidden";

    document.documentElement.appendChild(popup);
    return popup;
  }

  function positionPopupNearEditorFrame() {
    const t = getCkEditorTarget();
    if (!t || !popup) return;

    const r = t.frame.getBoundingClientRect();

    const top = Math.max(10, Math.min(window.innerHeight - 600, r.bottom + 10));
    const left = Math.max(10, Math.min(window.innerWidth - 540, r.left));

    popup.style.top = `${top}px`;
    popup.style.left = `${left}px`;
  }

  function hidePopup() {
    if (!popup) return;
    popup.style.display = "none";
  }

  function getDismissedUntil(diagnosisId) {
    return dismissedUntilByDiagnosis[diagnosisId] || 0;
  }

  function snoozeDiagnosis(diagnosisId, minutes = 15) {
    dismissedUntilByDiagnosis[diagnosisId] = Date.now() + minutes * 60 * 1000;
  }
  // ---- Rendering helpers ----
  function renderSectionFields(section) {
    if (!section || !section.fields) return "";

    return section.fields
      .map((field) => {
        const safeName = `field_${field.id}`;

        if (field.type === "radio") {
          const optionsHtml = (field.options || [])
            .map(
              (opt) => `
                <label style="display:block; margin:4px 0;">
                  <input type="radio" name="${safeName}" value="${opt}" data-field-id="${field.id}">
                  ${opt}
                </label>
              `,
            )
            .join("");

          return `
            <div style="margin-bottom:10px;">
              <div style="font-weight:600; margin-bottom:4px;">${field.label}</div>
              ${optionsHtml}
            </div>
          `;
        }

        if (field.type === "checkbox-group") {
          const optionsHtml = (field.options || [])
            .map(
              (opt) => `
                <label style="display:block; margin:4px 0;">
                  <input type="checkbox" value="${opt}" data-field-id="${field.id}">
                  ${opt}
                </label>
              `,
            )
            .join("");

          return `
            <div style="margin-bottom:10px;">
              <div style="font-weight:600; margin-bottom:4px;">${field.label}</div>
              ${optionsHtml}
            </div>
          `;
        }

        return "";
      })
      .join("");
  }

  function renderCollapsibleSection(section, openByDefault = false) {
    if (!section) return "";

    return `
    <details ${openByDefault ? "open" : ""} style="margin:16px 0 8px 0; border:1px solid #e5e7eb; border-radius:8px; padding:8px 10px; background:#fafafa;">
      <summary style="font-weight:700; cursor:pointer; outline:none;">
        ${section.title}
      </summary>
      <div style="margin-top:10px;">
        ${renderSectionFields(section)}
      </div>
    </details>
  `;
  }

  function getFieldSelections(container, fieldId) {
    return Array.from(
      container.querySelectorAll(`input[data-field-id="${fieldId}"]:checked`),
    ).map((el) => el.value);
  }

  function validateDiagnosis(container, diagnosis) {
    const errors = [];

    const renderedFieldIds = new Set(
      Array.from(container.querySelectorAll("[data-field-id]")).map((el) =>
        el.getAttribute("data-field-id"),
      ),
    );

    for (const rule of diagnosis.rules || []) {
      if (rule.fieldId && !renderedFieldIds.has(rule.fieldId)) {
        continue;
      }

      if (rule.fieldIds) {
        const anyRendered = rule.fieldIds.some((fieldId) =>
          renderedFieldIds.has(fieldId),
        );
        if (!anyRendered) {
          continue;
        }
      }

      if (rule.type === "require-min-selected") {
        const selected = getFieldSelections(container, rule.fieldId);
        if (selected.length < (rule.min || 1)) {
          errors.push(rule.message);
        }
      }

      if (rule.type === "require-single") {
        const selected = getFieldSelections(container, rule.fieldId);
        if (selected.length !== 1) {
          errors.push(rule.message);
        }
      }

      if (rule.type === "require-one-of-fields") {
        const renderedFieldIdsForRule = (rule.fieldIds || []).filter(
          (fieldId) => renderedFieldIds.has(fieldId),
        );

        const anySelected = renderedFieldIdsForRule.some(
          (fieldId) => getFieldSelections(container, fieldId).length > 0,
        );

        if (!anySelected && renderedFieldIdsForRule.length > 0) {
          errors.push(rule.message);
        }
      }
    }

    return errors;
  }
  //Validation Checking and Alerts
  function renderValidationErrors(container, errors) {
    let box = container.querySelector("#emr-validation-errors");

    if (!box) {
      box = document.createElement("div");
      box.id = "emr-validation-errors";
      box.style.margin = "0 0 10px 0";
      box.style.padding = "10px";
      box.style.border = "1px solid #f5c2c7";
      box.style.background = "#fff5f5";
      box.style.borderRadius = "8px";
      box.style.color = "#842029";
      box.style.fontSize = "12px";
      box.style.display = "none";

      const contentArea = container.querySelector("#emr-form-content");
      if (contentArea) {
        contentArea.prepend(box);
      }
    }

    if (!errors.length) {
      box.style.display = "none";
      box.innerHTML = "";
      return;
    }

    box.innerHTML = `
    <div style="font-weight:700; margin-bottom:6px;">
      Please complete required criteria before inserting:
    </div>
    <ul style="margin:0; padding-left:18px;">
      ${errors.map((e) => `<li>${e}</li>`).join("")}
    </ul>
  `;
    box.style.display = "block";
  }

  function clearValidationErrors(container) {
    const box = container.querySelector("#emr-validation-errors");
    if (box) {
      box.style.display = "none";
      box.innerHTML = "";
    }
  }

  // ---- Note insertion ----
  function insertTextIntoEditor(text) {
    const t = getCkEditorTarget();
    if (!t || !t.body) return false;

    const body = t.body;
    const current = body.innerText ? body.innerText.trim() : "";
    const newText = current ? `${current}\n\n${text}` : text;

    body.innerText = newText;

    body.dispatchEvent(new Event("input", { bubbles: true }));
    body.dispatchEvent(new Event("change", { bubbles: true }));
    body.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: " " }));

    return true;
  }

  function getSelectedRadioValue(container, fieldId) {
    return (
      container.querySelector(`input[data-field-id="${fieldId}"]:checked`)
        ?.value || ""
    );
  }

  function getSelectedCheckboxValues(container, fieldId) {
    return Array.from(
      container.querySelectorAll(`input[data-field-id="${fieldId}"]:checked`),
    )
      .map((el) => el.value)
      .filter((v) => v !== "N/A");
  }

  function buildChfNoteText(container) {
    const selectedAcuity = getSelectedRadioValue(container, "acuity");
    const selectedType = getSelectedRadioValue(container, "hf_type");
    const relatedIllnesses = getSelectedCheckboxValues(
      container,
      "related_illness",
    );

    const obsTriggers = getSelectedCheckboxValues(container, "obs_trigger");
    const obsFindings = getSelectedCheckboxValues(container, "obs_findings");
    const obsInterventions = getSelectedCheckboxValues(
      container,
      "obs_interventions",
    );

    const acutePathway = getSelectedRadioValue(container, "acute_pathway");
    const acuteSymptoms = getSelectedCheckboxValues(
      container,
      "acute_symptoms",
    );
    const acuteFindings = getSelectedCheckboxValues(
      container,
      "acute_findings",
    );
    const acuteInterventions = getSelectedCheckboxValues(
      container,
      "acute_interventions",
    );

    const intermediateSupport = getSelectedCheckboxValues(
      container,
      "intermediate_support",
    );

    const criticalCore = getSelectedCheckboxValues(container, "critical_core");
    const criticalAdvancedSupport = getSelectedCheckboxValues(
      container,
      "critical_advanced_support",
    );
    const criticalNippvPathway = getSelectedCheckboxValues(
      container,
      "critical_nippv_pathway",
    );

    let text = "CHF – CDI Documentation";

    if (selectedAcuity) text += `\n- Acuity: ${selectedAcuity}`;
    if (selectedType) text += `\n- Type: ${selectedType}`;
    if (relatedIllnesses.length)
      text += `\n- Related Illness: ${relatedIllnesses.join(", ")}`;

    if (obsTriggers.length || obsFindings.length || obsInterventions.length) {
      text += `\n\nCHF – Observation Criteria`;
    }
    if (obsTriggers.length) text += `\n- Trigger: ${obsTriggers.join(", ")}`;
    if (obsFindings.length) text += `\n- Findings: ${obsFindings.join(", ")}`;
    if (obsInterventions.length)
      text += `\n- Interventions: ${obsInterventions.join(", ")}`;

    if (
      acutePathway ||
      acuteSymptoms.length ||
      acuteFindings.length ||
      acuteInterventions.length
    ) {
      text += `\n\nCHF – Acute Inpatient Criteria`;
    }
    if (acutePathway) text += `\n- Pathway: ${acutePathway}`;
    if (acuteSymptoms.length)
      text += `\n- Symptoms: ${acuteSymptoms.join(", ")}`;
    if (acuteFindings.length)
      text += `\n- Findings: ${acuteFindings.join(", ")}`;
    if (acuteInterventions.length)
      text += `\n- Interventions: ${acuteInterventions.join(", ")}`;

    if (intermediateSupport.length) {
      text += `\n\nCHF – Intermediate Inpatient Criteria`;
      text += `\n- Support: ${intermediateSupport.join(", ")}`;
    }

    if (
      criticalCore.length ||
      criticalAdvancedSupport.length ||
      criticalNippvPathway.length
    ) {
      text += `\n\nCHF – Critical Inpatient Criteria`;
    }
    if (criticalCore.length)
      text += `\n- Core Criteria: ${criticalCore.join(", ")}`;
    if (criticalAdvancedSupport.length) {
      text += `\n- Advanced Support / Interventions: ${criticalAdvancedSupport.join(", ")}`;
    }
    if (criticalNippvPathway.length)
      text += `\n- NIPPV Pathway: ${criticalNippvPathway.join(", ")}`;

    return text;
  }

  function buildCopdNoteText(container) {
    const selectedAcuity = getSelectedRadioValue(container, "copd_acuity");
    const respFailure = getSelectedRadioValue(container, "resp_failure");
    const relatedConditions = getSelectedCheckboxValues(
      container,
      "copd_related",
    );

    const obsTriggers = getSelectedCheckboxValues(
      container,
      "copd_obs_trigger",
    );
    const obsFindings = getSelectedCheckboxValues(
      container,
      "copd_obs_findings",
    );
    const obsInterventions = getSelectedCheckboxValues(
      container,
      "copd_obs_interventions",
    );

    const acuteSymptoms = getSelectedCheckboxValues(
      container,
      "copd_acute_symptoms",
    );
    const acuteFindings = getSelectedCheckboxValues(
      container,
      "copd_acute_findings",
    );
    const acuteInterventions = getSelectedCheckboxValues(
      container,
      "copd_acute_interventions",
    );

    const intermediateSupport = getSelectedCheckboxValues(
      container,
      "copd_intermediate_support",
    );

    const criticalCore = getSelectedCheckboxValues(
      container,
      "copd_critical_core",
    );
    const criticalAdvanced = getSelectedCheckboxValues(
      container,
      "copd_critical_advanced",
    );
    const nippv = getSelectedCheckboxValues(container, "copd_nippv");

    let text = "COPD – CDI Documentation";

    if (selectedAcuity) text += `\n- Acuity: ${selectedAcuity}`;
    if (respFailure && respFailure !== "None")
      text += `\n- Respiratory Failure: ${respFailure}`;
    if (relatedConditions.length)
      text += `\n- Related Conditions: ${relatedConditions.join(", ")}`;

    if (obsTriggers.length || obsFindings.length || obsInterventions.length) {
      text += `\n\nCOPD – Observation Criteria`;
    }
    if (obsTriggers.length) text += `\n- Trigger: ${obsTriggers.join(", ")}`;
    if (obsFindings.length) text += `\n- Findings: ${obsFindings.join(", ")}`;
    if (obsInterventions.length)
      text += `\n- Interventions: ${obsInterventions.join(", ")}`;

    if (
      acuteSymptoms.length ||
      acuteFindings.length ||
      acuteInterventions.length
    ) {
      text += `\n\nCOPD – Acute Inpatient Criteria`;
    }
    if (acuteSymptoms.length)
      text += `\n- Symptoms: ${acuteSymptoms.join(", ")}`;
    if (acuteFindings.length)
      text += `\n- Findings: ${acuteFindings.join(", ")}`;
    if (acuteInterventions.length)
      text += `\n- Interventions: ${acuteInterventions.join(", ")}`;

    if (intermediateSupport.length) {
      text += `\n\nCOPD – Intermediate Inpatient Criteria`;
      text += `\n- Support: ${intermediateSupport.join(", ")}`;
    }

    if (criticalCore.length || criticalAdvanced.length || nippv.length) {
      text += `\n\nCOPD – Critical Inpatient Criteria`;
    }
    if (criticalCore.length)
      text += `\n- Core Criteria: ${criticalCore.join(", ")}`;
    if (criticalAdvanced.length) {
      text += `\n- Advanced Support / Interventions: ${criticalAdvanced.join(", ")}`;
    }
    if (nippv.length) text += `\n- NIPPV Pathway: ${nippv.join(", ")}`;

    return text;
  }

  function buildDiagnosisNoteText(diagnosis, container) {
    switch (diagnosis.id) {
      case "CHF":
        return buildChfNoteText(container);
      case "COPD":
        return buildCopdNoteText(container);
      default:
        return `${diagnosis.title}`;
    }
  }

  // ---- Dynamic diagnosis popup ----
  function showDiagnosisFormPopup(diagnosis) {
    const p = ensurePopup();
    positionPopupNearEditorFrame();

    const cdiSection = (diagnosis.sections || []).find(
      (s) => s.id === "cdi_doc",
    );
    const observationSection = (diagnosis.sections || []).find(
      (s) => s.id === "observation_criteria",
    );
    const acuteSection = (diagnosis.sections || []).find(
      (s) => s.id === "acute_inpatient_criteria",
    );
    const intermediateSection = (diagnosis.sections || []).find(
      (s) => s.id === "intermediate_inpatient_criteria",
    );
    const criticalSection = (diagnosis.sections || []).find(
      (s) => s.id === "critical_inpatient_criteria",
    );

    p.innerHTML = `
    <button id="emr-close" title="Close"
      style="position:absolute; top:8px; right:10px; border:none; background:transparent; cursor:pointer; font-size:16px;">
      ×
    </button>

    <div style="display:flex; flex-direction:column; max-height:75vh;">
      <div style="font-weight:700; margin:0 24px 8px 0; font-size:14px; flex:0 0 auto;">
        ${diagnosis.title}
      </div>

      <div id="emr-form-content" style="flex:1 1 auto; overflow:auto; padding-right:6px; min-height:0;">
        ${
          cdiSection
            ? renderCollapsibleSection(cdiSection, true)
            : "<div>No CDI section found.</div>"
        }

        ${observationSection ? renderCollapsibleSection(observationSection, true) : ""}
        ${acuteSection ? renderCollapsibleSection(acuteSection, false) : ""}
        ${intermediateSection ? renderCollapsibleSection(intermediateSection, false) : ""}
        ${criticalSection ? renderCollapsibleSection(criticalSection, false) : ""}
      </div>

      <div style="display:flex; gap:8px; margin-top:10px; flex:0 0 auto; padding-top:8px; border-top:1px solid #eee;">
        <button id="emr-insert"
          style="flex:1; border:1px solid #d0d7de; background:#f6f8fa; border-radius:10px; padding:7px 10px; cursor:pointer;">
          Insert into Note
        </button>
        <button id="emr-dismiss"
          style="flex:1; border:1px solid #d0d7de; background:#f6f8fa; border-radius:10px; padding:7px 10px; cursor:pointer;">
          Dismiss
        </button>
      </div>
    </div>
  `;

    const dismissCurrent = () => {
      snoozeDiagnosis(diagnosis.id, 15);
      hidePopup();
    };

    p.querySelector("#emr-close")?.addEventListener("click", dismissCurrent);
    p.querySelector("#emr-dismiss")?.addEventListener("click", dismissCurrent);

    p.querySelector("#emr-insert")?.addEventListener("click", () => {
      const errors = validateDiagnosis(p, diagnosis);

      if (errors.length) {
        renderValidationErrors(p, errors);
        return;
      }

      clearValidationErrors(p);

      // CDI
      const selectedAcuity =
        p.querySelector('input[data-field-id="acuity"]:checked')?.value || "";

      const selectedType =
        p.querySelector('input[data-field-id="hf_type"]:checked')?.value || "";

      const relatedIllnesses = Array.from(
        p.querySelectorAll('input[data-field-id="related_illness"]:checked'),
      ).map((el) => el.value);

      // Observation
      const obsTriggers = Array.from(
        p.querySelectorAll('input[data-field-id="obs_trigger"]:checked'),
      ).map((el) => el.value);

      const obsFindings = Array.from(
        p.querySelectorAll('input[data-field-id="obs_findings"]:checked'),
      ).map((el) => el.value);

      const obsInterventions = Array.from(
        p.querySelectorAll('input[data-field-id="obs_interventions"]:checked'),
      ).map((el) => el.value);

      // Acute
      const acutePathway =
        p.querySelector('input[data-field-id="acute_pathway"]:checked')
          ?.value || "";

      const acuteSymptoms = Array.from(
        p.querySelectorAll('input[data-field-id="acute_symptoms"]:checked'),
      ).map((el) => el.value);

      const acuteFindings = Array.from(
        p.querySelectorAll('input[data-field-id="acute_findings"]:checked'),
      ).map((el) => el.value);

      const acuteInterventions = Array.from(
        p.querySelectorAll(
          'input[data-field-id="acute_interventions"]:checked',
        ),
      ).map((el) => el.value);

      // Intermediate
      const intermediateSupport = Array.from(
        p.querySelectorAll(
          'input[data-field-id="intermediate_support"]:checked',
        ),
      ).map((el) => el.value);

      // Critical
      const criticalCore = Array.from(
        p.querySelectorAll('input[data-field-id="critical_core"]:checked'),
      ).map((el) => el.value);

      const criticalAdvancedSupport = Array.from(
        p.querySelectorAll(
          'input[data-field-id="critical_advanced_support"]:checked',
        ),
      ).map((el) => el.value);

      const criticalNippvPathway = Array.from(
        p.querySelectorAll(
          'input[data-field-id="critical_nippv_pathway"]:checked',
        ),
      ).map((el) => el.value);

      let text = "CHF – CDI Documentation";

      if (selectedAcuity) {
        text += `\n- Acuity: ${selectedAcuity}`;
      }

      if (selectedType) {
        text += `\n- Type: ${selectedType}`;
      }

      if (relatedIllnesses.length) {
        text += `\n- Related Illness: ${relatedIllnesses.join(", ")}`;
      }

      if (obsTriggers.length || obsFindings.length || obsInterventions.length) {
        text += `\n\nCHF – Observation Criteria`;
      }

      if (obsTriggers.length) {
        text += `\n- Trigger: ${obsTriggers.join(", ")}`;
      }

      if (obsFindings.length) {
        text += `\n- Findings: ${obsFindings.join(", ")}`;
      }

      if (obsInterventions.length) {
        text += `\n- Interventions: ${obsInterventions.join(", ")}`;
      }

      if (
        acutePathway ||
        acuteSymptoms.length ||
        acuteFindings.length ||
        acuteInterventions.length
      ) {
        text += `\n\nCHF – Acute Inpatient Criteria`;
      }

      if (acutePathway) {
        text += `\n- Pathway: ${acutePathway}`;
      }

      if (acuteSymptoms.length) {
        text += `\n- Symptoms: ${acuteSymptoms.join(", ")}`;
      }

      if (acuteFindings.length) {
        text += `\n- Findings: ${acuteFindings.join(", ")}`;
      }

      if (acuteInterventions.length) {
        text += `\n- Interventions: ${acuteInterventions.join(", ")}`;
      }

      if (intermediateSupport.length) {
        text += `\n\nCHF – Intermediate Inpatient Criteria`;
        text += `\n- Support: ${intermediateSupport.join(", ")}`;
      }

      if (
        criticalCore.length ||
        criticalAdvancedSupport.length ||
        criticalNippvPathway.length
      ) {
        text += `\n\nCHF – Critical Inpatient Criteria`;
      }

      if (criticalCore.length) {
        text += `\n- Core Criteria: ${criticalCore.join(", ")}`;
      }

      if (criticalAdvancedSupport.length) {
        text += `\n- Advanced Support / Interventions: ${criticalAdvancedSupport.join(", ")}`;
      }

      if (criticalNippvPathway.length) {
        text += `\n- NIPPV Pathway: ${criticalNippvPathway.join(", ")}`;
      }
      /*
      Remove comment to have popup close after insert
      const ok = insertTextIntoEditor(text);

            if (ok) {
              snoozeDiagnosis(diagnosis.id, 15);
              hidePopup(); // ← ADD THIS LINE
            }

            const btn = p.querySelector("#emr-insert");
            if (btn) {
              btn.textContent = ok ? "Inserted!" : "Insert failed";
              setTimeout(() => {
                btn.textContent = "Insert into Note";
              }, 1200);
            }
          });
      */
      // Gives breif notice of inserted before closing. Must comment out if using above
      p.querySelector("#emr-insert")?.addEventListener("click", () => {
        const errors = validateDiagnosis(p, diagnosis);

        if (errors.length) {
          renderValidationErrors(p, errors);
          return;
        }

        clearValidationErrors(p);

        const text = buildDiagnosisNoteText(diagnosis, p);
        const ok = insertTextIntoEditor(text);

        const btn = p.querySelector("#emr-insert");
        if (btn) {
          btn.textContent = ok ? "Inserted!" : "Insert failed";
        }

        if (ok) {
          snoozeDiagnosis(diagnosis.id, 15);
          setTimeout(() => {
            hidePopup();
          }, 500);
        }

        if (btn) {
          setTimeout(() => {
            btn.textContent = "Insert into Note";
          }, 1200);
        }
      });
    });

    p.querySelectorAll("input[type='checkbox'][data-field-id]").forEach(
      (input) => {
        input.addEventListener("change", () => {
          const fieldId = input.getAttribute("data-field-id");
          const group = p.querySelectorAll(`input[data-field-id="${fieldId}"]`);

          if (input.value === "N/A" && input.checked) {
            // uncheck all others
            group.forEach((el) => {
              if (el !== input) el.checked = false;
            });
          } else if (input.value !== "N/A" && input.checked) {
            // uncheck N/A
            group.forEach((el) => {
              if (el.value === "N/A") el.checked = false;
            });
          }
        });
      },
    );

    p.style.display = "block";
  }

  // Reposition on scroll/resize
  window.addEventListener(
    "scroll",
    () => {
      if (popup && popup.style.display === "block") {
        positionPopupNearEditorFrame();
      }
    },
    true,
  );

  window.addEventListener("resize", () => {
    if (popup && popup.style.display === "block") {
      positionPopupNearEditorFrame();
    }
  });

  // ---- Scan + attach observers to the CKEditor BODY ----
  const scan = debounce(() => {
    const editorText = getEditorText();

    if (!editorText) {
      lastMatched = null;
      hidePopup();
      return;
    }

    const match = findDiagnosisMatch(editorText);

    if (!match) {
      lastMatched = null;
      hidePopup();
      return;
    }

    if (Date.now() < getDismissedUntil(match.id) && lastMatched === match.id) {
      return;
    }

    if (lastMatched !== match.id) {
      lastMatched = match.id;
      showDiagnosisFormPopup(match);
    }
  }, 200);

  let mo = null;

  function attachToEditorBody() {
    const t = getCkEditorTarget();
    if (!t) return;

    const body = t.body;

    if (body.dataset.emrWired === "1") return;
    body.dataset.emrWired = "1";

    console.log(
      "[EMR] Wired CKEditor body via parent frame (doc URL:",
      t.doc.URL,
      ")",
    );

    mo?.disconnect();
    mo = new MutationObserver(() => scan());
    mo.observe(body, { subtree: true, childList: true, characterData: true });

    body.addEventListener("keyup", scan, true);
    body.addEventListener("paste", scan, true);
    body.addEventListener("input", scan, true);

    scan();
  }

  // CKEditor iframe is often created later; re-try
  (async () => {
    await loadDiagnosesConfig();
    attachToEditorBody();
    setInterval(attachToEditorBody, 1000);
  })();
})();
