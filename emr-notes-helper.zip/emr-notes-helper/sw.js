// sw.js
chrome.runtime.onInstalled.addListener(() => {
  console.log("[SW] installed");
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  console.log("[SW] message:", msg, "from:", sender?.url);
});
