const STORAGE_KEY = "diagnosesConfig";
const PREFERENCES_KEY = "emrUserPreferences";
let diagnoses = [];
let selectedIndex = -1;
let selectedSectionIndex = -1;
let selectedFieldIndex = -1;
let selectedRuleIndex = -1;

const el = {
  popupPosition: document.getElementById("popupPosition"),
  btnSavePreferences: document.getElementById("btnSavePreferences"),
  list: document.getElementById("diagnosisList"),
  status: document.getElementById("status"),
  dxId: document.getElementById("dxId"),
  dxTitle: document.getElementById("dxTitle"),
  dxKeywords: document.getElementById("dxKeywords"),
  jsonPreview: document.getElementById("jsonPreview"),
  btnLoadDefaults: document.getElementById("btnLoadDefaults"),
  btnNewDiagnosis: document.getElementById("btnNewDiagnosis"),
  btnSaveAll: document.getElementById("btnSaveAll"),
  btnExportJson: document.getElementById("btnExportJson"),
  btnSaveDiagnosis: document.getElementById("btnSaveDiagnosis"),
  btnDeleteDiagnosis: document.getElementById("btnDeleteDiagnosis"),
  sectionList: document.getElementById("sectionList"),
  sectionId: document.getElementById("sectionId"),
  sectionTitle: document.getElementById("sectionTitle"),
  btnNewSection: document.getElementById("btnNewSection"),
  btnDeleteSection: document.getElementById("btnDeleteSection"),
  btnSaveSection: document.getElementById("btnSaveSection"),
  fieldList: document.getElementById("fieldList"),
  fieldId: document.getElementById("fieldId"),
  fieldLabel: document.getElementById("fieldLabel"),
  fieldType: document.getElementById("fieldType"),
  fieldOptions: document.getElementById("fieldOptions"),
  btnNewField: document.getElementById("btnNewField"),
  btnDeleteField: document.getElementById("btnDeleteField"),
  btnSaveField: document.getElementById("btnSaveField"),
  ruleList: document.getElementById("ruleList"),
  ruleType: document.getElementById("ruleType"),
  ruleFieldId: document.getElementById("ruleFieldId"),
  ruleFieldIds: document.getElementById("ruleFieldIds"),
  ruleMin: document.getElementById("ruleMin"),
  ruleMessage: document.getElementById("ruleMessage"),
  btnNewRule: document.getElementById("btnNewRule"),
  btnDeleteRule: document.getElementById("btnDeleteRule"),
  btnSaveRule: document.getElementById("btnSaveRule"),
};
// HELPERS
function setStatus(msg) {
  el.status.textContent = msg;
}

function renderList() {
  el.list.innerHTML = "";
  diagnoses.forEach((dx, index) => {
    const item = document.createElement("div");
    item.className = "listitem" + (index === selectedIndex ? " active" : "");
    item.innerHTML = `<strong>${dx.id || "(no id)"}</strong><br><span class="muted">${dx.title || ""}</span>`;
    item.addEventListener("click", () => {
      selectedIndex = index;
      loadSelectedDiagnosis();
      renderList();
    });
    el.list.appendChild(item);
  });
}

function renderPreview() {
  el.jsonPreview.textContent = JSON.stringify(diagnoses, null, 2);
}

function clearForm() {
  el.dxId.value = "";
  el.dxTitle.value = "";
  el.dxKeywords.value = "";
  clearSectionForm();
  renderSectionList();
  clearFieldForm();
  renderFieldList();
  clearRuleForm();
  renderRuleList();
}

function loadSelectedDiagnosis() {
  const dx = diagnoses[selectedIndex];
  if (!dx) {
    clearForm();
    return;
  }

  el.dxId.value = dx.id || "";
  el.dxTitle.value = dx.title || "";
  el.dxKeywords.value = (dx.keywords || []).join("\n");

  selectedSectionIndex = -1;
  clearSectionForm();
  renderSectionList();
  selectedFieldIndex = -1;
  clearFieldForm();
  renderFieldList();
  selectedRuleIndex = -1;
  clearRuleForm();
  renderRuleList();
}

function saveCurrentDiagnosis() {
  if (selectedIndex < 0) return;

  const existing = diagnoses[selectedIndex] || {};
  diagnoses[selectedIndex] = {
    ...existing,
    id: el.dxId.value.trim(),
    title: el.dxTitle.value.trim(),
    keywords: el.dxKeywords.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean),
    sections: existing.sections || [],
    rules: existing.rules || [],
  };

  renderList();
  renderPreview();
  renderSectionList();
}

async function loadDefaultsFromJson() {
  try {
    const url = chrome.runtime.getURL("diagnoses.json");
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    diagnoses = await res.json();
    selectedIndex = diagnoses.length ? 0 : -1;
    renderList();
    renderPreview();
    loadSelectedDiagnosis();
    setStatus("Loaded defaults from diagnoses.json");
  } catch (err) {
    console.error(err);
    setStatus("Failed to load diagnoses.json");
  }
}

async function saveToStorage() {
  try {
    if (selectedIndex >= 0) saveCurrentDiagnosis();
    if (selectedIndex >= 0 && selectedSectionIndex >= 0) saveCurrentSection();
    if (
      selectedIndex >= 0 &&
      selectedSectionIndex >= 0 &&
      selectedFieldIndex >= 0
    ) {
      saveCurrentField();
    }
    if (selectedIndex >= 0 && selectedRuleIndex >= 0) {
      saveCurrentRule();
    }

    await chrome.storage.local.set({ [STORAGE_KEY]: diagnoses });
    setStatus("Saved diagnoses to extension storage");
  } catch (err) {
    console.error(err);
    setStatus("Failed to save to storage");
  }
}

async function loadFromStorage() {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    if (Array.isArray(result[STORAGE_KEY]) && result[STORAGE_KEY].length) {
      diagnoses = result[STORAGE_KEY];
      selectedIndex = 0;
      renderList();
      renderPreview();
      loadSelectedDiagnosis();
      setStatus("Loaded diagnoses from storage");
      return true;
    }
  } catch (err) {
    console.error(err);
  }
  return false;
}

function newDiagnosis() {
  diagnoses.push({
    id: "",
    title: "",
    keywords: [],
    sections: [],
    rules: [],
  });
  selectedIndex = diagnoses.length - 1;
  selectedSectionIndex = -1;
  selectedRuleIndex = -1;
  renderList();
  renderPreview();
  loadSelectedDiagnosis();
  setStatus("New diagnosis created");
}

function deleteDiagnosis() {
  if (selectedIndex < 0) return;
  diagnoses.splice(selectedIndex, 1);
  selectedIndex = diagnoses.length ? Math.max(0, selectedIndex - 1) : -1;
  renderList();
  renderPreview();
  loadSelectedDiagnosis();
  setStatus("Diagnosis deleted");
  selectedRuleIndex = -1;
  clearRuleForm();
  renderRuleList();
}

function exportJson() {
  if (selectedIndex >= 0) saveCurrentDiagnosis();
  if (selectedIndex >= 0 && selectedSectionIndex >= 0) saveCurrentSection();
  if (
    selectedIndex >= 0 &&
    selectedSectionIndex >= 0 &&
    selectedFieldIndex >= 0
  ) {
    saveCurrentField();
  }
  if (selectedIndex >= 0 && selectedRuleIndex >= 0) {
    saveCurrentRule();
  }

  const blob = new Blob([JSON.stringify(diagnoses, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "diagnoses.json";
  a.click();
  URL.revokeObjectURL(url);
  setStatus("Exported JSON");
}

function clearSectionForm() {
  el.sectionId.value = "";
  el.sectionTitle.value = "";
}

function renderSectionList() {
  el.sectionList.innerHTML = "";

  const dx = diagnoses[selectedIndex];
  const sections = dx?.sections || [];

  sections.forEach((section, index) => {
    const item = document.createElement("div");
    item.className =
      "listitem" + (index === selectedSectionIndex ? " active" : "");
    item.innerHTML = `<strong>${section.id || "(no id)"}</strong><br><span class="muted">${section.title || ""}</span>`;
    item.addEventListener("click", () => {
      selectedSectionIndex = index;
      loadSelectedSection();
      renderSectionList();
    });
    el.sectionList.appendChild(item);
  });
}

function loadSelectedSection() {
  const dx = diagnoses[selectedIndex];
  const section = dx?.sections?.[selectedSectionIndex];

  if (!section) {
    clearSectionForm();
    return;
  }

  el.sectionId.value = section.id || "";
  el.sectionTitle.value = section.title || "";

  selectedFieldIndex = -1;
  clearFieldForm();
  renderFieldList();
}

function saveCurrentSection() {
  const dx = diagnoses[selectedIndex];
  if (!dx || selectedSectionIndex < 0) return;

  if (!Array.isArray(dx.sections)) dx.sections = [];

  const existing = dx.sections[selectedSectionIndex] || {};
  dx.sections[selectedSectionIndex] = {
    ...existing,
    id: el.sectionId.value.trim(),
    title: el.sectionTitle.value.trim(),
    fields: existing.fields || [],
  };

  renderSectionList();
  renderPreview();
}

function newSection() {
  const dx = diagnoses[selectedIndex];
  if (!dx) return;

  if (!Array.isArray(dx.sections)) dx.sections = [];

  dx.sections.push({
    id: "",
    title: "",
    fields: [],
  });

  selectedSectionIndex = dx.sections.length - 1;
  renderSectionList();
  loadSelectedSection();
  renderPreview();
  setStatus("New section created");
}

function deleteSection() {
  const dx = diagnoses[selectedIndex];
  if (!dx || selectedSectionIndex < 0) return;

  dx.sections.splice(selectedSectionIndex, 1);
  selectedSectionIndex = dx.sections.length
    ? Math.max(0, selectedSectionIndex - 1)
    : -1;

  renderSectionList();
  loadSelectedSection();
  renderPreview();
  setStatus("Section deleted");
  selectedFieldIndex = -1;
  clearFieldForm();
  renderFieldList();
}

function clearFieldForm() {
  el.fieldId.value = "";
  el.fieldLabel.value = "";
  el.fieldType.value = "radio";
  el.fieldOptions.value = "";
}

function renderFieldList() {
  el.fieldList.innerHTML = "";

  const dx = diagnoses[selectedIndex];
  const section = dx?.sections?.[selectedSectionIndex];
  const fields = section?.fields || [];

  fields.forEach((field, index) => {
    const item = document.createElement("div");
    item.className =
      "listitem" + (index === selectedFieldIndex ? " active" : "");
    item.innerHTML = `<strong>${field.id || "(no id)"}</strong><br><span class="muted">${field.label || ""} • ${field.type || ""}</span>`;
    item.addEventListener("click", () => {
      selectedFieldIndex = index;
      loadSelectedField();
      renderFieldList();
    });
    el.fieldList.appendChild(item);
  });
}

function loadSelectedField() {
  const dx = diagnoses[selectedIndex];
  const section = dx?.sections?.[selectedSectionIndex];
  const field = section?.fields?.[selectedFieldIndex];

  if (!field) {
    clearFieldForm();
    return;
  }

  el.fieldId.value = field.id || "";
  el.fieldLabel.value = field.label || "";
  el.fieldType.value = field.type || "radio";
  el.fieldOptions.value = (field.options || []).join("\n");
}

function saveCurrentField() {
  const dx = diagnoses[selectedIndex];
  const section = dx?.sections?.[selectedSectionIndex];
  if (!dx || !section || selectedFieldIndex < 0) return;

  if (!Array.isArray(section.fields)) section.fields = [];

  const existing = section.fields[selectedFieldIndex] || {};
  section.fields[selectedFieldIndex] = {
    ...existing,
    id: el.fieldId.value.trim(),
    label: el.fieldLabel.value.trim(),
    type: el.fieldType.value,
    options: el.fieldOptions.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean),
  };

  renderFieldList();
  renderPreview();
}

function newField() {
  const dx = diagnoses[selectedIndex];
  const section = dx?.sections?.[selectedSectionIndex];
  if (!dx || !section) return;

  if (!Array.isArray(section.fields)) section.fields = [];

  section.fields.push({
    id: "",
    label: "",
    type: "radio",
    options: [],
  });

  selectedFieldIndex = section.fields.length - 1;
  renderFieldList();
  loadSelectedField();
  renderPreview();
  setStatus("New field created");
}

function deleteField() {
  const dx = diagnoses[selectedIndex];
  const section = dx?.sections?.[selectedSectionIndex];
  if (!dx || !section || selectedFieldIndex < 0) return;

  section.fields.splice(selectedFieldIndex, 1);
  selectedFieldIndex = section.fields.length
    ? Math.max(0, selectedFieldIndex - 1)
    : -1;

  renderFieldList();
  loadSelectedField();
  renderPreview();
  setStatus("Field deleted");
}

function clearRuleForm() {
  el.ruleType.value = "require-single";
  el.ruleFieldId.value = "";
  el.ruleFieldIds.value = "";
  el.ruleMin.value = "1";
  el.ruleMessage.value = "";
}

function renderRuleList() {
  el.ruleList.innerHTML = "";

  const dx = diagnoses[selectedIndex];
  const rules = dx?.rules || [];

  rules.forEach((rule, index) => {
    const item = document.createElement("div");
    item.className =
      "listitem" + (index === selectedRuleIndex ? " active" : "");

    const primary =
      rule.type === "require-one-of-fields"
        ? (rule.fieldIds || []).join(", ")
        : rule.fieldId || "";

    item.innerHTML = `<strong>${rule.type || "(no type)"}</strong><br><span class="muted">${primary}</span>`;
    item.addEventListener("click", () => {
      selectedRuleIndex = index;
      loadSelectedRule();
      renderRuleList();
    });
    el.ruleList.appendChild(item);
  });
}

function loadSelectedRule() {
  const dx = diagnoses[selectedIndex];
  const rule = dx?.rules?.[selectedRuleIndex];

  if (!rule) {
    clearRuleForm();
    return;
  }

  el.ruleType.value = rule.type || "require-single";
  el.ruleFieldId.value = rule.fieldId || "";
  el.ruleFieldIds.value = (rule.fieldIds || []).join("\n");
  el.ruleMin.value = String(rule.min ?? 1);
  el.ruleMessage.value = rule.message || "";
}

function saveCurrentRule() {
  const dx = diagnoses[selectedIndex];
  if (!dx || selectedRuleIndex < 0) return;

  if (!Array.isArray(dx.rules)) dx.rules = [];

  const type = el.ruleType.value;
  const rule = {
    type,
    message: el.ruleMessage.value.trim(),
  };

  if (type === "require-single" || type === "require-min-selected") {
    rule.fieldId = el.ruleFieldId.value.trim();
  }

  if (type === "require-min-selected") {
    const parsed = parseInt(el.ruleMin.value.trim(), 10);
    rule.min = Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
  }

  if (type === "require-one-of-fields") {
    rule.fieldIds = el.ruleFieldIds.value
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
  }

  dx.rules[selectedRuleIndex] = rule;

  renderRuleList();
  renderPreview();
}

function newRule() {
  const dx = diagnoses[selectedIndex];
  if (!dx) return;

  if (!Array.isArray(dx.rules)) dx.rules = [];

  dx.rules.push({
    type: "require-single",
    fieldId: "",
    message: "",
  });

  selectedRuleIndex = dx.rules.length - 1;
  renderRuleList();
  loadSelectedRule();
  renderPreview();
  setStatus("New rule created");
}

function deleteRule() {
  const dx = diagnoses[selectedIndex];
  if (!dx || selectedRuleIndex < 0) return;

  dx.rules.splice(selectedRuleIndex, 1);
  selectedRuleIndex = dx.rules.length ? Math.max(0, selectedRuleIndex - 1) : -1;

  renderRuleList();
  loadSelectedRule();
  renderPreview();
  setStatus("Rule deleted");
}

async function loadPreferences() {
  try {
    const result = await chrome.storage.local.get(PREFERENCES_KEY);
    const prefs = result[PREFERENCES_KEY] || {};

    el.popupPosition.value = prefs.popupPosition || "right";
  } catch (err) {
    console.error(err);
    setStatus("Failed to load preferences");
  }
}

async function savePreferences() {
  try {
    const prefs = {
      popupPosition: el.popupPosition.value || "right",
    };

    await chrome.storage.local.set({ [PREFERENCES_KEY]: prefs });
    setStatus("Preferences saved");
  } catch (err) {
    console.error(err);
    setStatus("Failed to save preferences");
  }
}

//END HELPERS

el.btnNewSection.addEventListener("click", newSection);
el.btnDeleteSection.addEventListener("click", deleteSection);
el.btnSaveSection.addEventListener("click", () => {
  saveCurrentSection();
  setStatus("Section saved");
});
el.btnLoadDefaults.addEventListener("click", loadDefaultsFromJson);
el.btnNewDiagnosis.addEventListener("click", newDiagnosis);
el.btnSaveAll.addEventListener("click", saveToStorage);
el.btnExportJson.addEventListener("click", exportJson);
el.btnSaveDiagnosis.addEventListener("click", () => {
  saveCurrentDiagnosis();
  setStatus("Diagnosis saved in editor");
});
el.btnDeleteDiagnosis.addEventListener("click", deleteDiagnosis);
el.btnNewField.addEventListener("click", newField);
el.btnDeleteField.addEventListener("click", deleteField);
el.btnSaveField.addEventListener("click", () => {
  saveCurrentField();
  setStatus("Field saved");
});
el.btnNewRule.addEventListener("click", newRule);
el.btnDeleteRule.addEventListener("click", deleteRule);
el.btnSaveRule.addEventListener("click", () => {
  saveCurrentRule();
  setStatus("Rule saved");
});

el.btnSavePreferences.addEventListener("click", savePreferences);

(async function init() {
  const loaded = await loadFromStorage();
  if (!loaded) {
    await loadDefaultsFromJson();
  }
  await loadPreferences();
})();
