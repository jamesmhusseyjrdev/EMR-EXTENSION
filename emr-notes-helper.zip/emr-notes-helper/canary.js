(() => {
  document.title = "[CANARY RUN] " + document.title;
  console.log("[CANARY] injected into:", location.href);
})();
